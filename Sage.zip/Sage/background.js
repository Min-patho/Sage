
chrome.runtime.onInstalled.addListener(() => {
  console.log("GPT Voice Agent FINAL version installed.");
});
