let currentState = "idle";
let currentFolder = "default";
let activityTimer = null;
let emotionTimer = null;

// Avatar settings with default values
let avatarSettings = {
  size: 225,
  position: { bottom: 2, right: 10 },
  opacity: 1.0
};

// 創建頭像圖片
const image = document.createElement("img");
image.src = chrome.runtime.getURL(`assets/${currentFolder}/idle.webp`);

// Function to validate position to prevent avatar from going off-screen
function validatePosition() {
  const viewportWidth = window.innerWidth;
  const viewportHeight = window.innerHeight;
  const avatarSize = avatarSettings.size;
  
  // Prevent going too far left (right value too high)
  const maxRight = viewportWidth - 50; // Keep at least 50px visible
  if (avatarSettings.position.right > maxRight) {
    avatarSettings.position.right = maxRight;
  }
  
  // Prevent going too far up (bottom value too high) 
  const maxBottom = viewportHeight - 50; // Keep at least 50px visible
  if (avatarSettings.position.bottom > maxBottom) {
    avatarSettings.position.bottom = maxBottom;
  }
  
  // Prevent negative values that would hide the avatar
  if (avatarSettings.position.right < -avatarSize + 50) {
    avatarSettings.position.right = -avatarSize + 50;
  }
  if (avatarSettings.position.bottom < -avatarSize + 50) {
    avatarSettings.position.bottom = -avatarSize + 50;
  }
}

// Function to update avatar style based on settings
function updateAvatarStyle() {
  validatePosition();
  image.style.cssText = `
    position: fixed;
    bottom: ${avatarSettings.position.bottom}px;
    right: ${avatarSettings.position.right}px;
    width: ${avatarSettings.size}px;
    height: ${avatarSettings.size}px;
    z-index: 9999;
    opacity: ${avatarSettings.opacity} !important;
    pointer-events: auto;
  `;
}

updateAvatarStyle();

image.addEventListener('mouseenter', () => {
  resetRestingTimer();
  triggerRandomEmotion();
  log("Hover emotion triggered + sleep timer reset");
});

// Right-click context menu
image.addEventListener('contextmenu', (e) => {
  e.preventDefault();
  showSettingsMenu(e.clientX, e.clientY);
});

// 添加呼吸動畫和設定選單樣式
const styleSheet = document.createElement("style");
styleSheet.textContent = `
  @keyframes breathing {
    0%   { transform: scale(1); opacity: 0.9; filter: blur(0.2px); }
    50%  { transform: scale(1); opacity: 1.0; filter: blur(0px); }
    100% { transform: scale(1); opacity: 0.9; filter: blur(0.2px); }
  }
  img[style*="position: fixed"] {
    animation: breathing 6s ease-in-out infinite;
    border-radius: 10px;
    mask: linear-gradient(to right, transparent 0%, black 5%, black 95%, transparent 100%),
          linear-gradient(to bottom, transparent 0%, black 5%, black 95%, transparent 100%);
    mask-composite: intersect;
  }
  
  .claude-avatar-settings {
    position: fixed;
    background: white;
    border: 1px solid #ccc;
    border-radius: 8px;
    padding: 16px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    z-index: 10000;
    font-family: system-ui, -apple-system, sans-serif;
    font-size: 14px;
    min-width: 250px;
  }
  
  .claude-avatar-settings h3 {
    margin: 0 0 12px 0;
    font-size: 16px;
    color: #333;
  }
  
  .claude-avatar-settings .setting-item {
    margin-bottom: 12px;
  }
  
  .claude-avatar-settings label {
    display: block;
    margin-bottom: 4px;
    font-weight: 500;
    color: #555;
  }
  
  .claude-avatar-settings input[type="range"], 
  .claude-avatar-settings input[type="number"] {
    width: 100%;
    margin-bottom: 4px;
  }
  
  .claude-avatar-settings .position-controls {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 8px;
  }
  
  .claude-avatar-settings button {
    background: #007bff;
    color: white;
    border: none;
    padding: 8px 16px;
    border-radius: 4px;
    cursor: pointer;
    margin-right: 8px;
  }
  
  .claude-avatar-settings button:hover {
    background: #0056b3;
  }
  
  .claude-avatar-settings button.secondary {
    background: #6c757d;
  }
  
  .claude-avatar-settings button.secondary:hover {
    background: #545b62;
  }
`;
document.head.appendChild(styleSheet);
document.body.appendChild(image);

// Settings menu functionality
function showSettingsMenu(x, y) {
  // Remove existing menu if any
  const existingMenu = document.querySelector('.claude-avatar-settings');
  if (existingMenu) {
    existingMenu.remove();
  }
  
  const menu = document.createElement('div');
  menu.className = 'claude-avatar-settings';
  
  // Position in center of viewport
  menu.style.left = '50%';
  menu.style.top = '50%';
  menu.style.transform = 'translate(-50%, -50%)';
  
  // Calculate dynamic ranges based on viewport size
  const viewportWidth = window.innerWidth;
  const viewportHeight = window.innerHeight;
  const maxRight = Math.max(viewportWidth, 1920); // At least 1920px range
  const maxBottom = Math.max(viewportHeight, 1080); // At least 1080px range

  menu.innerHTML = `
    <h3>Avatar Settings</h3>
    
    <div class="setting-item">
      <label>Size: <span id="size-value">${avatarSettings.size}px</span></label>
      <input type="range" id="size-slider" min="100" max="800" value="${avatarSettings.size}">
    </div>
    
    <div class="setting-item">
      <label>Position</label>
      <div class="position-controls">
        <div>
          <label>Right: <span id="right-value">${avatarSettings.position.right}px</span></label>
          <input type="range" id="right-slider" min="-400" max="${maxRight}" value="${avatarSettings.position.right}">
        </div>
        <div>
          <label>Bottom: <span id="bottom-value">${avatarSettings.position.bottom}px</span></label>
          <input type="range" id="bottom-slider" min="-400" max="${maxBottom}" value="${avatarSettings.position.bottom}">
        </div>
      </div>
    </div>
    
    <div class="setting-item">
      <label>Opacity: <span id="opacity-value">${(avatarSettings.opacity * 100).toFixed(0)}%</span></label>
      <input type="range" id="opacity-slider" min="10" max="100" value="${avatarSettings.opacity * 100}">
    </div>
    
    <div class="setting-item">
      <button id="reset-btn">Reset to Defaults</button>
      <button class="secondary" id="close-btn">Close</button>
    </div>
  `;
  
  document.body.appendChild(menu);
  
  // Add event listeners for real-time updates
  setupSettingsListeners();
  
  // Close menu when clicking outside
  setTimeout(() => {
    document.addEventListener('click', closeSettingsOnOutsideClick);
  }, 100);
}

function setupSettingsListeners() {
  const sizeSlider = document.getElementById('size-slider');
  const rightSlider = document.getElementById('right-slider');
  const bottomSlider = document.getElementById('bottom-slider');
  const opacitySlider = document.getElementById('opacity-slider');
  const resetBtn = document.getElementById('reset-btn');
  const closeBtn = document.getElementById('close-btn');
  
  sizeSlider.addEventListener('input', (e) => {
    avatarSettings.size = parseInt(e.target.value);
    document.getElementById('size-value').textContent = avatarSettings.size + 'px';
    updateAvatarStyle();
    // Update position sliders if position was corrected due to size change
    rightSlider.value = avatarSettings.position.right;
    bottomSlider.value = avatarSettings.position.bottom;
    document.getElementById('right-value').textContent = avatarSettings.position.right + 'px';
    document.getElementById('bottom-value').textContent = avatarSettings.position.bottom + 'px';
  });
  
  rightSlider.addEventListener('input', (e) => {
    avatarSettings.position.right = parseInt(e.target.value);
    updateAvatarStyle();
    // Update display and slider if value was corrected by validation
    document.getElementById('right-value').textContent = avatarSettings.position.right + 'px';
    if (e.target.value != avatarSettings.position.right) {
      e.target.value = avatarSettings.position.right;
    }
  });
  
  bottomSlider.addEventListener('input', (e) => {
    avatarSettings.position.bottom = parseInt(e.target.value);
    updateAvatarStyle();
    // Update display and slider if value was corrected by validation
    document.getElementById('bottom-value').textContent = avatarSettings.position.bottom + 'px';
    if (e.target.value != avatarSettings.position.bottom) {
      e.target.value = avatarSettings.position.bottom;
    }
  });
  
  opacitySlider.addEventListener('input', (e) => {
    avatarSettings.opacity = parseInt(e.target.value) / 100;
    document.getElementById('opacity-value').textContent = Math.round(avatarSettings.opacity * 100) + '%';
    updateAvatarStyle();
  });
  
  resetBtn.addEventListener('click', resetToDefaults);
  closeBtn.addEventListener('click', closeSettingsMenu);
}

function closeSettingsMenu() {
  const menu = document.querySelector('.claude-avatar-settings');
  if (menu) {
    menu.remove();
  }
  document.removeEventListener('click', closeSettingsOnOutsideClick);
}

function closeSettingsOnOutsideClick(e) {
  const menu = document.querySelector('.claude-avatar-settings');
  if (menu && !menu.contains(e.target)) {
    closeSettingsMenu();
  }
}

function resetToDefaults() {
  avatarSettings = {
    size: 225,
    position: { bottom: 2, right: 10 },
    opacity: 1.0
  };
  updateAvatarStyle();
  
  // Update slider values
  const sizeSlider = document.getElementById('size-slider');
  const rightSlider = document.getElementById('right-slider');
  const bottomSlider = document.getElementById('bottom-slider');
  const opacitySlider = document.getElementById('opacity-slider');
  
  if (sizeSlider) {
    sizeSlider.value = avatarSettings.size;
    document.getElementById('size-value').textContent = avatarSettings.size + 'px';
  }
  if (rightSlider) {
    rightSlider.value = avatarSettings.position.right;
    document.getElementById('right-value').textContent = avatarSettings.position.right + 'px';
  }
  if (bottomSlider) {
    bottomSlider.value = avatarSettings.position.bottom;
    document.getElementById('bottom-value').textContent = avatarSettings.position.bottom + 'px';
  }
  if (opacitySlider) {
    opacitySlider.value = avatarSettings.opacity * 100;
    document.getElementById('opacity-value').textContent = Math.round(avatarSettings.opacity * 100) + '%';
  }
}

// Make functions global so they can be called from HTML
window.closeSettingsMenu = closeSettingsMenu;
window.resetToDefaults = resetToDefaults;

// 日誌函數
function log(message) {
  console.log("[Claude Avatar]", message);
}

// 更新圖片顯示
function updateImage() {
  try {
    const newSrc = chrome.runtime.getURL(`assets/${currentFolder}/${currentState}.webp`);
    
    // 測試圖片是否存在
    const testImg = new Image();
    testImg.onload = () => {
      image.src = newSrc;
      log(`Image updated: ${currentFolder}/${currentState}`);
    };
    testImg.onerror = () => {
      // 如果載入失敗，fallback到default
      const fallbackSrc = chrome.runtime.getURL(`assets/default/${currentState}.webp`);
      image.src = fallbackSrc;
      log(`Fallback to default: ${currentState}`);
    };
    testImg.src = newSrc;
  } catch (error) {
    log(`❌ Error updating image: ${error.message}`);
  }
}

function triggerRandomEmotion() {
  const emotions = ["happy", "excited", "focused"];
  const randomEmotion = emotions[Math.floor(Math.random() * emotions.length)];
  
  currentState = randomEmotion;
  updateImage();
  log(`Emotion triggered: ${randomEmotion}`);
  
  // 10秒後回到idle
  if (emotionTimer) clearTimeout(emotionTimer);
  emotionTimer = setTimeout(() => {
    currentState = "idle";
    updateImage();
    log("Emotion reset to idle");
  }, 7500);
}

// 1. 偵測Project名稱並更新資料夾
function updateProjectFolder() {
  const projectElements = document.querySelectorAll('div.truncate');
  let projectName = null;
  
  for (let element of projectElements) {
    const text = element.textContent.trim();
    if (text.includes('/')) {
      projectName = text.split('/')[0].trim();
      break;
    }
  }
  
  // 直接使用Project名稱作為資料夾名稱
  let targetFolder = "default"; // 預設值
  if (projectName) {
    targetFolder = projectName;
  }
  
  // 只在資料夾真的改變時才更新
  if (targetFolder !== currentFolder) {
    currentFolder = targetFolder;
    updateImage();
    log(`Project detected: ${projectName} → ${targetFolder}`);
  }
}

// 檢查輸入狀態（定時呼叫）
function checkInputAndUpdateState() {
  // 檢查輸入框是否有內容
  const inputSelectors = [
    'div[aria-label="Write your prompt to Claude"]',
    'div[contenteditable="true"]',
    'textarea',
    '[data-testid="chat-input"]'
  ];
  
  let hasInput = false;
  for (let selector of inputSelectors) {
    const input = document.querySelector(selector);
    if (input && input.textContent && input.textContent.trim().length > 0) {
      hasInput = true;
      break;
    }
  }
  
  // 只在有輸入內容時才重設計時器
  if (hasInput) {
    resetRestingTimer();
    
    // 如果不是情緒狀態，切換到listening
    if (currentState !== "happy" && currentState !== "excited" && currentState !== "focused") {
      if (currentState !== "listening") {
        currentState = "listening";
        updateImage();
        log("State changed to: listening");
      }
    }
  } else {
    // 沒有輸入內容，如果不是情緒狀態或resting狀態，切換到idle
    if (currentState !== "happy" && currentState !== "excited" && currentState !== "focused" && currentState !== "resting") {
      if (currentState !== "idle") {
        currentState = "idle";
        updateImage();
        log("State changed to: idle");
      }
    }
  }
}

// 重設睡眠計時器
function resetRestingTimer() {
  if (activityTimer) {
    clearTimeout(activityTimer);
  }
  
  activityTimer = setTimeout(() => {
    if (currentState !== "happy" && currentState !== "excited" && currentState !== "focused") {
      currentState = "resting";
      updateImage();
      log("State changed to: resting");
    }
  }, 600000); // 10分鐘
}

// 綁定輸入監聽 - 改用定時檢查
function bindInputListeners() {
  // 每0.5秒檢查一次輸入狀態
  setInterval(() => {
    checkInputAndUpdateState();
  }, 500);
  
  log("Input polling started (every 0.5 second)");
}

// 綁定頁面活動監聽
function bindActivityListeners() {
  // 🔥 移除所有活動監聽，只保留log
  log("Minimal activity listeners bound");
}

// 初始化
function initialize() {
  log("Avatar Extension initialized");
  
  // 綁定事件監聽
  bindInputListeners();
  bindActivityListeners();
  
  // 初始狀態檢查和啟動計時器
  checkInputAndUpdateState();
  resetRestingTimer();
  
  // 初始Project檢查
  setTimeout(updateProjectFolder, 2000);
  
  // 定期檢查Project變化（每3秒）
  setInterval(updateProjectFolder, 3000);
}

// 啟動
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initialize);
} else {
  initialize();
}

